# Stereochemistry correction instructions

This replaces the original `scripts/03_build_features.py`.

## What it corrects

1. Uses PubChem `isomeric_smiles` rather than connectivity-only SMILES.
2. Writes canonical SMILES with `isomericSmiles=True`.
3. Generates Morgan fingerprints with `includeChirality=True`.
4. Identifies exact structures using the full standardized InChIKey.
5. Keeps stereoisomers such as isotretinoin/tretinoin and amlodipine/levamlodipine separate.
6. Excludes exact duplicate structures carrying conflicting primary labels rather than choosing one arbitrarily.
7. Retains one representative for exact same-structure, same-label duplicates.
8. Produces dedicated duplicate and stereoisomer-family audit files.

## Colab steps

Upload `03_build_features_corrected.py` into the project `scripts` folder, then run:

```python
%cd /content/DILI_Molecular_Prediction

# Preserve the old script for provenance
!cp scripts/03_build_features.py scripts/03_build_features_original.py

# Replace it with the corrected version
!cp /content/03_build_features_corrected.py scripts/03_build_features.py

# Delete only generated outputs so they cannot be mixed with old results
!rm -rf data/processed/*
!rm -rf tables/*
!rm -rf supplementary/models/*

# Rebuild features and rerun all downstream analyses
!python scripts/03_build_features.py
!python scripts/04_train_models.py
!python scripts/05_make_report.py
```

Then package the corrected outputs:

```python
!zip -r /content/DILI_corrected_results.zip \
  data/processed tables supplementary manuscript scripts/03_build_features.py
```

Download `DILI_corrected_results.zip` and upload it to ChatGPT.

## Quality-control checks

Run:

```python
import pandas as pd
m = pd.read_csv("data/processed/molecule_metadata.csv")

for names in [
    ["isotretinoin", "tretinoin"],
    ["amlodipine", "levamlodipine"],
    ["armodafinil", "modafinil"],
]:
    print(m[m["compound_name"].str.lower().isin(names)][
        ["compound_name", "standardized_isomeric_smiles",
         "standardized_inchikey", "primary_label"]
    ])
```

For each pair, the full standardized InChIKeys should differ when the compounds are true stereochemical/geometric variants.

Also inspect:

- `data/processed/duplicate_structures_stereo_preserved_audit.csv`
- `data/processed/stereoisomer_family_audit.csv`
- `data/processed/structure_exclusions.csv`

Do not update the manuscript's numerical Results until the corrected pipeline finishes.
